package com.tonny.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.Locale

class TonnyService : Service(), TextToSpeech.OnInitListener {

    companion object {
        var instance: TonnyService? = null
    }

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("tonny", "Tonny", NotificationManager.IMPORTANCE_LOW)
        )
        val n = NotificationCompat.Builder(this, "tonny")
            .setContentTitle("Tonny sun raha hai")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        tts?.language = Locale("hi", "IN")
        say("Ji boss, Tonny taiyaar hai")
        handler.postDelayed({ listen() }, 2500)
    }

    fun say(msg: String) {
        tts?.speak(msg, TextToSpeech.QUEUE_ADD, null, "tonny")
    }

    private fun listen() {
        if (instance == null) return
        if (tts?.isSpeaking == true) {
            handler.postDelayed({ listen() }, 700)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()?.let { handle(it) }
                    handler.postDelayed({ listen() }, 500)
                }
                override fun onError(error: Int) {
                    handler.postDelayed({ listen() }, 1000)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            })
        }
    }

    private fun handle(text: String) {
        val t = text.lowercase()
        val name = listOf("tonny", "tony", "टोनी", "टॉनी", "टोनि").firstOrNull { t.contains(it) } ?: return
        val cmd = t.substringAfter(name).trim()
        val prefs = getSharedPreferences("tonny", MODE_PRIVATE)
        when {
            cmd.isEmpty() -> say("Ji boss?")
            cmd.contains("याद रख") || cmd.contains("yaad rakh") -> {
                val note = cmd.replace("याद रखो", "").replace("याद रख", "")
                    .replace("yaad rakho", "").replace("yaad rakh", "").trim()
                prefs.edit().putString("notes", (prefs.getString("notes", "") ?: "") + note + ". ").apply()
                say("Theek hai boss, yaad rakh liya: $note")
            }
            cmd.contains("क्या याद") || cmd.contains("kya yaad") ->
                say("Boss, aapne kaha tha: " + (prefs.getString("notes", "")?.ifBlank { "kuch nahi" }))
            else -> say("Boss, aapne kaha: $cmd. Ye kaam main abhi seekh raha hoon.")
        }
    }

    override fun onDestroy() {
        instance = null
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
