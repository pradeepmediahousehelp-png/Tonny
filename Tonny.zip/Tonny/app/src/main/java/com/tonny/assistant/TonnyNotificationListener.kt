package com.tonny.assistant

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class TonnyNotificationListener : NotificationListenerService() {

    // BOSS: yahan apne khaas logon ke naam (jaise phone me save hain) likho
    private val vip = listOf("mummy", "papa")

    // In shabdon wale message ko bhi emergency maana jayega
    private val urgent = listOf("urgent", "emergency", "help", "jaruri", "zaruri", "जरूरी", "इमरजेंसी")

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString() ?: return
        val text = extras.getCharSequence("android.text")?.toString() ?: ""
        val all = "$title $text".lowercase()

        val fromVip = vip.any { title.lowercase().contains(it) }
        val isUrgent = urgent.any { all.contains(it) }

        if (fromVip || isUrgent) {
            TonnyService.instance?.say("Boss, $title ka emergency hai: $text")
        }
    }
}
