package com.tonny.assistant

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private fun prefs() = getSharedPreferences("tonny", MODE_PRIVATE)

    private fun refresh() {
        val p = prefs()
        status.text = "Awaaz register: " + (if (p.getString("vp", null) != null) "haan" else "nahi") +
            "\nAwaaz lock: " + (if (p.getBoolean("lock", true)) "ON" else "OFF") +
            "\nLimit: " + "%.1f".format(p.getFloat("th", 1.2f)) +
            "\nAakhri check: " + p.getString("last", "-")
    }

    private fun askPermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS,
                Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE
            ),
            1
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        status = TextView(this)
        box.addView(status)
        fun btn(label: String, action: () -> Unit) {
            box.addView(Button(this).apply {
                text = label
                setOnClickListener { action(); refresh() }
            })
        }
        btn("1. Permission do (mic, contacts, call)") { askPermissions() }
        btn("2. Notification access ON karo") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btn("3. Dusre apps ke upar dikhne ki permission") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("4. Accessibility ON karo (Tonny)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("5. Tonny ko START karo") {
            ContextCompat.startForegroundService(this, Intent(this, TonnyService::class.java))
        }
        btn("Tonny ko BAND karo") { stopService(Intent(this, TonnyService::class.java)) }
        btn("Awaaz lock ON / OFF") {
            prefs().edit().putBoolean("lock", !prefs().getBoolean("lock", true)).apply()
        }
        btn("Lock ZYADA strict") {
            prefs().edit().putFloat("th", maxOf(0.4f, prefs().getFloat("th", 1.2f) - 0.2f)).apply()
        }
        btn("Lock KAM strict") {
            prefs().edit().putFloat("th", minOf(3.0f, prefs().getFloat("th", 1.2f) + 0.2f)).apply()
        }
        btn("Meri awaaz RESET (dobara register)") { prefs().edit().remove("vp").apply() }
        btn("Status dikhao") { }
        setContentView(ScrollView(this).apply { addView(box) })
        askPermissions()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }
}
