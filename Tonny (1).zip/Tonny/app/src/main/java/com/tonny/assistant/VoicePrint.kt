package com.tonny.assistant

/** Simple voiceprint: average MFCC of speech frames (16 kHz mono PCM). */
object VoicePrint {
    private const val SR = 16000
    private const val N = 512
    private const val NM = 26
    private const val NC = 13
    private val mel = melBank()

    private fun hz2mel(f: Double) = 2595 * Math.log10(1 + f / 700)
    private fun mel2hz(m: Double) = 700 * (Math.pow(10.0, m / 2595) - 1)

    private fun melBank(): Array<DoubleArray> {
        val hi = hz2mel(SR / 2.0)
        val pts = DoubleArray(NM + 2) { mel2hz(hi * it / (NM + 1)) }
        val bins = IntArray(NM + 2) { Math.floor((N + 1) * pts[it] / SR).toInt() }
        return Array(NM) { m ->
            val f = DoubleArray(N / 2 + 1)
            val up = (bins[m + 1] - bins[m]).coerceAtLeast(1)
            val down = (bins[m + 2] - bins[m + 1]).coerceAtLeast(1)
            for (k in bins[m] until bins[m + 1]) f[k] = (k - bins[m]).toDouble() / up
            for (k in bins[m + 1] until bins[m + 2]) f[k] = (bins[m + 2] - k).toDouble() / down
            f
        }
    }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val t = re[i]; re[i] = re[j]; re[j] = t
                val u = im[i]; im[i] = im[j]; im[j] = u
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2 * Math.PI / len
            var i = 0
            while (i < n) {
                for (k in 0 until len / 2) {
                    val wr = Math.cos(ang * k); val wi = Math.sin(ang * k)
                    val a = i + k; val b = i + k + len / 2
                    val xr = re[b] * wr - im[b] * wi
                    val xi = re[b] * wi + im[b] * wr
                    re[b] = re[a] - xr; im[b] = im[a] - xi
                    re[a] += xr; im[a] += xi
                }
                i += len
            }
            len = len shl 1
        }
    }

    private fun mfcc(x: DoubleArray, s: Int): DoubleArray {
        val re = DoubleArray(N)
        val im = DoubleArray(N)
        for (i in 0 until 400) {
            val v = x[s + i] - (if (i > 0) 0.97 * x[s + i - 1] else 0.0)
            re[i] = v * (0.54 - 0.46 * Math.cos(2 * Math.PI * i / 399))
        }
        fft(re, im)
        val p = DoubleArray(N / 2 + 1) { re[it] * re[it] + im[it] * im[it] }
        val le = DoubleArray(NM) { m ->
            var e = 0.0
            for (k in p.indices) e += p[k] * mel[m][k]
            Math.log(e + 1e-10)
        }
        return DoubleArray(NC) { c ->
            var a = 0.0
            for (m in 0 until NM) a += le[m] * Math.cos(Math.PI * c * (m + 0.5) / NM)
            a
        }
    }

    /** 24 numbers: mean and std of MFCC 1..12 over speech frames, or null if too quiet/short. */
    fun features(pcm: ShortArray): FloatArray? {
        if (pcm.size < 8000) return null
        val x = DoubleArray(pcm.size) { pcm[it] / 32768.0 }
        val starts = (0..(x.size - 400) step 160).toList()
        val en = starts.map { s ->
            var e = 0.0
            for (i in s until s + 400) e += x[i] * x[i]
            e / 400
        }
        val avg = en.average()
        if (avg < 1e-8) return null
        val feats = ArrayList<DoubleArray>()
        for ((idx, s) in starts.withIndex()) if (en[idx] > avg * 0.5) feats.add(mfcc(x, s))
        if (feats.size < 40) return null
        val out = FloatArray(24)
        for (c in 1..12) {
            val m = feats.map { it[c] }.average()
            val sd = Math.sqrt(feats.map { (it[c] - m) * (it[c] - m) }.average())
            out[c - 1] = m.toFloat()
            out[12 + c - 1] = sd.toFloat()
        }
        return out
    }

    /** Smaller = more similar. */
    fun distance(t: FloatArray, e: FloatArray): Float {
        var s = 0.0
        for (i in 0 until 12) {
            val sd = maxOf(e[12 + i].toDouble(), 1e-3)
            val z = (t[i] - e[i]) / sd
            s += z * z
        }
        return Math.sqrt(s / 12).toFloat()
    }
}
