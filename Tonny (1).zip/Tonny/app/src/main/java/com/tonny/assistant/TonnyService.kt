package com.tonny.assistant

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.Locale

class TonnyService : Service(), TextToSpeech.OnInitListener {

    companion object { var instance: TonnyService? = null }

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var pending: Intent? = null
    private var pendingAt = 0L
    private val ring = ShortArray(16000 * 12)
    private var written = 0L
    private var rec: AudioRecord? = null

    private val aliases = mapOf(
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "whatsapp" to "whatsapp",
        "इंस्टाग्राम" to "instagram", "instagram" to "instagram",
        "यूट्यूब" to "youtube", "youtube" to "youtube",
        "फेसबुक" to "facebook", "facebook" to "facebook",
        "क्रोम" to "chrome", "chrome" to "chrome",
        "कैमरा" to "camera", "camera" to "camera",
        "टेलीग्राम" to "telegram", "telegram" to "telegram",
        "सेटिंग" to "settings", "settings" to "settings",
        "गैलरी" to "gallery", "gallery" to "gallery"
    )
    private val family = mapOf("मम्मी" to "mummy", "पापा" to "papa", "भैया" to "bhaiya", "दीदी" to "didi")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("tonny", "Tonny", NotificationManager.IMPORTANCE_LOW)
        )
        val n = NotificationCompat.Builder(this, "tonny")
            .setContentTitle("Tonny sun raha hai")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        tts = TextToSpeech(this, this)
        startMic()
    }

    override fun onInit(status: Int) {
        tts?.language = Locale("hi", "IN")
        val hi = tts?.voices?.filter { it.locale.language == "hi" } ?: emptyList()
        hi.firstOrNull {
            it.name.contains("hic") || it.name.contains("hid") ||
                (it.name.contains("male") && !it.name.contains("female"))
        }?.let { tts?.voice = it }
        tts?.setPitch(0.8f)
        say("Ji boss, Tonny taiyaar hai")
        handler.postDelayed({ listen() }, 2500)
    }

    fun say(msg: String) {
        tts?.speak(msg, TextToSpeech.QUEUE_ADD, null, "tonny")
    }

    // ---- mic buffer for voice check ----
    private fun startMic() {
        try {
            val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 16000)
            )
            r.startRecording()
            rec = r
            Thread {
                val buf = ShortArray(1600)
                while (instance != null) {
                    val n = r.read(buf, 0, buf.size)
                    if (n <= 0) { Thread.sleep(20); continue }
                    synchronized(ring) {
                        for (i in 0 until n) {
                            ring[(written % ring.size).toInt()] = buf[i]
                            written++
                        }
                    }
                }
            }.start()
        } catch (e: Exception) { }
    }

    private fun lastSamples(sec: Float): ShortArray = synchronized(ring) {
        val n = minOf((sec * 16000).toLong(), ring.size.toLong(), written).toInt()
        ShortArray(n) { ring[((written - n + it) % ring.size).toInt()] }
    }

    private fun voiceOk(): Boolean {
        val prefs = getSharedPreferences("tonny", MODE_PRIVATE)
        val saved = prefs.getString("vp", null) ?: return true
        if (!prefs.getBoolean("lock", true)) return true
        val f = VoicePrint.features(lastSamples(4f))
        if (f == null) {
            prefs.edit().putString("last", "mic se awaaz nahi mili (silent/short)").apply()
            return false
        }
        val e = saved.split(",").map { it.toFloat() }.toFloatArray()
        val d = VoicePrint.distance(f, e)
        val th = prefs.getFloat("th", 1.2f)
        prefs.edit().putString("last", "distance %.2f (limit %.1f)".format(d, th)).apply()
        return d <= th
    }

    private fun enroll() {
        say("Boss, ab das second tak kuch bhi bolte rahiye")
        handler.postDelayed({
            val f = VoicePrint.features(lastSamples(10f))
            if (f == null) {
                say("Boss, awaaz saaf nahi mili, dobara koshish kijiye")
            } else {
                getSharedPreferences("tonny", MODE_PRIVATE).edit()
                    .putString("vp", f.joinToString(",")).apply()
                say("Boss, aapki awaaz yaad kar li. Ab sirf aapki awaaz se chalunga")
            }
        }, 14500)
    }

    // ---- listening ----
    private fun listen() {
        if (instance == null) return
        if (tts?.isSpeaking == true) {
            handler.postDelayed({ listen() }, 700)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()?.let { handle(it) }
                    handler.postDelayed({ listen() }, 500)
                }
                override fun onError(error: Int) { handler.postDelayed({ listen() }, 1000) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            })
        }
    }

    // ---- commands ----
    private fun handle(text: String) {
        val t = text.lowercase()
        val name = listOf("tonny", "tony", "टोनी", "टॉनी", "टोनि").firstOrNull { t.contains(it) }
        if (System.currentTimeMillis() - pendingAt > 20000) pending = null
        if (name == null && pending == null) return
        if (!voiceOk()) {
            if (name != null) say("Ye aapki awaaz nahi hai")
            return
        }
        pending?.let { p ->
            if (t.length <= 30) {
                if (listOf("हाँ", "हां", "haan", "yes", "जी", "kar do", "कर दो").any { t.contains(it) }) {
                    pending = null
                    try { startActivity(p); say("Ji boss") } catch (e: Exception) { say("Boss, ye kaam nahi ho paaya") }
                    return
                }
                if (listOf("नहीं", "नही", "nahi", "no ").any { t.contains(it) }) {
                    pending = null
                    say("Theek hai boss")
                    return
                }
            }
        }
        if (name == null) return
        val cmd = t.substringAfter(name).trim()
        val prefs = getSharedPreferences("tonny", MODE_PRIVATE)
        when {
            cmd.isEmpty() -> say("Ji boss?")
            (cmd.contains("आवाज") && cmd.contains("याद")) || cmd.contains("awaaz yaad") -> enroll()
            cmd.contains("call") || cmd.contains("कॉल") || cmd.contains("फोन कर") -> callCmd(cmd)
            cmd.contains("पीछे") || cmd.contains("back") -> nav(AccessibilityService.GLOBAL_ACTION_BACK)
            cmd.contains("होम") || cmd.contains("home") -> nav(AccessibilityService.GLOBAL_ACTION_HOME)
            cmd.contains("नोटिफिकेशन") || cmd.contains("notification") -> nav(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            cmd.contains("रीसेंट") || cmd.contains("recent") -> nav(AccessibilityService.GLOBAL_ACTION_RECENTS)
            cmd.contains("लॉक") || cmd.contains("lock") ->
                nav(if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN else -1)
            cmd.contains("खोल") || cmd.contains("khol") || cmd.contains("open") -> openApp(cmd)
            cmd.contains("याद रख") || cmd.contains("yaad rakh") -> {
                val note = cmd.replace("याद रखो", "").replace("याद रख", "")
                    .replace("yaad rakho", "").replace("yaad rakh", "").trim()
                prefs.edit().putString("notes", (prefs.getString("notes", "") ?: "") + note + ". ").apply()
                say("Theek hai boss, yaad rakh liya: $note")
            }
            cmd.contains("क्या याद") || cmd.contains("kya yaad") ->
                say("Boss, aapne kaha tha: " + (prefs.getString("notes", "")?.ifBlank { "kuch nahi" }))
            else -> say("Boss, aapne kaha: $cmd. Ye kaam main abhi seekh raha hoon.")
        }
    }

    private fun nav(action: Int) {
        val s = TonnyAccessibilityService.instance
        if (s == null || action < 0) { say("Boss, pehle accessibility ON kijiye"); return }
        s.performGlobalAction(action)
        say("Ji boss")
    }

    private fun ask(intent: Intent, question: String) {
        pending = intent
        pendingAt = System.currentTimeMillis()
        say(question)
    }

    private fun openApp(cmd: String) {
        val key = aliases.entries.firstOrNull { cmd.contains(it.key) }?.value
        if (key == null) { say("Boss, kaun sa app kholna hai?"); return }
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(main, 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(key) }
        val intent = app?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (intent == null) { say("Boss, $key phone me nahi mila"); return }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ask(intent, "Boss, $key kholun?")
    }

    private fun callCmd(cmd: String) {
        var who = cmd.substringBefore(" को").substringBefore(" ko")
            .replace("call", "").replace("कॉल", "").replace("करो", "").replace("karo", "").trim()
        family[who]?.let { who = it }
        var found: Pair<String, String>? = null
        try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                arrayOf("%$who%"), null
            )?.use { if (it.moveToFirst()) found = Pair(it.getString(0), it.getString(1)) }
        } catch (e: Exception) { }
        val f = found
        if (who.isEmpty() || f == null) { say("Boss, contact nahi mila"); return }
        val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(f.second)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ask(i, "Boss, ${f.first} ko call karun?")
    }

    override fun onDestroy() {
        instance = null
        try { rec?.stop(); rec?.release() } catch (e: Exception) { }
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
